<?php
include('conex.php');
date_default_timezone_get("America/Lima");
$latitud  	= $_POST["latitud"];
$longitud 	= $_POST["longitud"];
$datos 		= $_POST['datos'];
$dni		= $_POST['dni'];
$celular	= $_POST['celular'];
$direccion	= $_POST['direccion'];
$tipo		= $_POST['tipo'];
$observacion= $_POST['observacion'];
$hora	   = date('h:i');
$fecha	   = date('Y-m-d');

$auto=mysql_query("SELECT * FROM solicitudes_alertas");
$numero=mysql_num_rows($auto);
if($numero==0){
	$cod=1;
	}else{
		$cod=$numero+1;
		}
 $sql=mysql_query("INSERT INTO solicitudes_alertas VALUES ('$cod','$datos','$dni','$celular','$direccion','$latitud','$longitud','$tipo','$fecha','$hora','$observacion','','ESPERA')");

echo '<br>'.'Se guardo la Informacion!';
// $PHP_grupo = $_GET["txtGrupo"];

#$datos=mysql_query("SELECT * FROM tbl_estudiantes WHERE grupo ='$PHP_grupo'");

#$arrDatos = array();
#while ($rs=mysql_fetch_array($datos))
#{
#        $arrDatos[] = array_map('utf8_encode', $rs);
#}

#echo json_encode($arrDatos);

?>
